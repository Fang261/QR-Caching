package pt.iade.joaotomas.qrcaching.models.repositories;

import org.springframework.data.repository.CrudRepository;

import pt.iade.joaotomas.qrcaching.models.Ulq;


public interface UlqRepository extends CrudRepository<Ulq, Integer> { }
